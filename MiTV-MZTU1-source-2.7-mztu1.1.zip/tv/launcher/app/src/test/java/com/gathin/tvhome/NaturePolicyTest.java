package com.gathin.tvhome;

import org.junit.Test;
import java.net.URI;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import static org.junit.Assert.*;

public class NaturePolicyTest {
    private static final long NOW = 1_792_922_400_000L;

    @Test public void catalogOnlyRequestsFixedHttpsFourKJpegs() {
        Set<String> urls = new HashSet<>();
        for (int i = 0; i < NaturePolicy.count(); i++) {
            URI uri = URI.create(NaturePolicy.url(i));
            assertEquals("https", uri.getScheme());
            assertEquals("images.unsplash.com", uri.getHost());
            assertNull(uri.getUserInfo());
            assertTrue(uri.getQuery().contains("w=3840&h=2160"));
            assertTrue(uri.getQuery().contains("fm=jpg"));
            assertTrue(NaturePolicy.cacheName(NaturePolicy.fileName(i)));
            assertTrue(urls.add(uri.toString()));
        }
    }

    @Test public void invalidCacheNamesCannotBecomePathsOrUrls() {
        assertFalse(NaturePolicy.cacheName("../photo.jpg"));
        assertFalse(NaturePolicy.cacheName("download-123.part"));
        assertThrows(IllegalArgumentException.class, () -> NaturePolicy.url(-1));
        assertThrows(IllegalArgumentException.class, () -> NaturePolicy.fileName(100));
    }

    @Test public void consecutivePicturesNeverRepeat() {
        Random random = new Random(71);
        int previous = -1;
        for (int i = 0; i < 200; i++) {
            int picked = NaturePolicy.pick(previous, random);
            assertTrue(NaturePolicy.valid(picked));
            assertNotEquals(previous, picked);
            previous = picked;
        }
    }

    @Test public void doesNotDownloadAgainOnFrequentHomeVisits() {
        assertEquals(NaturePolicy.INTERVAL,
                NaturePolicy.delay(NOW, true, NOW, NOW, false));
        assertEquals(NaturePolicy.INTERVAL - 15 * 60_000L,
                NaturePolicy.delay(NOW + 15 * 60_000L, true, NOW, NOW, false));
    }

    @Test public void overdueHourProducesOneRefreshRatherThanReplayingMissedHours() {
        assertEquals(0, NaturePolicy.delay(NOW + NaturePolicy.INTERVAL, true, NOW, NOW, false));
        assertEquals(0, NaturePolicy.delay(NOW + 24 * NaturePolicy.INTERVAL, true, NOW, NOW, false));
        assertEquals(NaturePolicy.INTERVAL,
                NaturePolicy.delay(NOW + 24 * NaturePolicy.INTERVAL, true,
                        NOW + 24 * NaturePolicy.INTERVAL, NOW + 24 * NaturePolicy.INTERVAL, false));
    }

    @Test public void missingCacheTriggersImmediateDownload() {
        assertEquals(0, NaturePolicy.delay(NOW, false, NOW, NOW, false));
    }

    @Test public void failedDownloadBacksOffWithOrWithoutAnOldPicture() {
        for (boolean hasCache : new boolean[]{true, false}) {
            assertEquals(HeaderData.RETRY_INTERVAL,
                    NaturePolicy.delay(NOW, hasCache, NOW - NaturePolicy.INTERVAL, NOW, true));
            assertEquals(0, NaturePolicy.delay(NOW + HeaderData.RETRY_INTERVAL,
                    hasCache, NOW - NaturePolicy.INTERVAL, NOW, true));
        }
    }

    @Test public void clockResetDoesNotFreezeTheWallpaper() {
        assertEquals(0, NaturePolicy.delay(NOW - 60_000L, true, NOW, NOW, false));
    }
}
