package com.gathin.tvhome;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import org.json.JSONException;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/** Non-focusable header data. No service, alarm, job, or network activity outside Home. */
final class HeaderFeeds implements AutoCloseable {
    private static final String TAG = "TvHome.Header";
    private final Context context;
    private final SharedPreferences cache;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final HeaderHttp http = new HeaderHttp();
    private final TextView quotes, quotesInfo, weather, weatherInfo;
    private final boolean cryptoEnabled, weatherEnabled;
    private volatile boolean active;
    private volatile int generation;
    private Future<?> request;
    private final Runnable tick = this::refreshIfDue;

    HeaderFeeds(Context context, View root, boolean cryptoEnabled, boolean weatherEnabled) {
        this.context = context.getApplicationContext();
        cache = this.context.getSharedPreferences("header_feeds", Context.MODE_PRIVATE);
        this.cryptoEnabled = cryptoEnabled;
        this.weatherEnabled = weatherEnabled;
        root.findViewById(R.id.cryptoPanel).setVisibility(cryptoEnabled ? View.VISIBLE : View.GONE);
        root.findViewById(R.id.weatherPanel).setVisibility(weatherEnabled ? View.VISIBLE : View.GONE);
        quotes = root.findViewById(R.id.cryptoQuotes);
        quotesInfo = root.findViewById(R.id.cryptoInfo);
        weather = root.findViewById(R.id.weatherValue);
        weatherInfo = root.findViewById(R.id.weatherInfo);
    }

    void start() {
        if (active || (!cryptoEnabled && !weatherEnabled)) return;
        active = true;
        generation++;
        render(); // Show the durable cache immediately, before any network response.
        main.post(tick);
    }

    void stop() {
        active = false;
        generation++;
        main.removeCallbacks(tick);
        if (request != null) request.cancel(true);
        http.cancel();
    }

    private boolean current(int token) {
        return active && generation == token;
    }

    private void refreshIfDue() {
        if (!active) return;
        long now = System.currentTimeMillis();
        boolean getCrypto = cryptoEnabled && delay("crypto", now, HeaderData.CRYPTO_INTERVAL) == 0;
        boolean getWeather = weatherEnabled && delay("weather", now, HeaderData.WEATHER_INTERVAL) == 0;
        if (!getCrypto && !getWeather) {
            scheduleNext();
            return;
        }
        int token = generation;
        request = worker.submit(() -> {
            try {
                if (getCrypto && current(token)) fetch("crypto", HeaderHttp.QUOTES_URL, token);
                if (getWeather && current(token)) fetch("weather", HeaderHttp.WEATHER_URL, token);
            } finally {
                main.post(() -> {
                    if (current(token)) {
                        render();
                        scheduleNext();
                    }
                });
            }
        });
    }

    private long delay(String feed, long now, long interval) {
        return HeaderData.refreshDelay(now, cache.getLong(feed + "_attempt", 0), interval,
                cache.getBoolean(feed + "_failed", false));
    }

    private void scheduleNext() {
        if (!active) return;
        long now = System.currentTimeMillis();
        long next = Long.MAX_VALUE;
        if (cryptoEnabled) next = Math.min(next, delay("crypto", now, HeaderData.CRYPTO_INTERVAL));
        if (weatherEnabled) next = Math.min(next, delay("weather", now, HeaderData.WEATHER_INTERVAL));
        main.removeCallbacks(tick);
        main.postDelayed(tick, Math.max(1000L, next));
    }

    private void fetch(String feed, String endpoint, int token) {
        String body = null;
        try {
            body = http.get(endpoint, () -> current(token));
            if ("crypto".equals(feed)) HeaderData.parseQuotes(body);
            else HeaderData.parseWeather(body);
        } catch (IOException | JSONException | RuntimeException error) {
            body = null;
            if (current(token)) Log.w(TAG, "Cannot refresh " + feed, error);
        }
        if (!current(token)) return; // Cancelled requests neither overwrite data nor postpone the next retry.
        SharedPreferences.Editor edit = cache.edit()
                .putLong(feed + "_attempt", System.currentTimeMillis())
                .putBoolean(feed + "_failed", body == null);
        if (body != null) edit.putString(feed + "_body", body);
        edit.apply();
        // A slow weather request must not hold back already loaded quotes.
        main.post(() -> { if (current(token)) render(); });
    }

    private void render() {
        long now = System.currentTimeMillis();
        if (cryptoEnabled) {
            try {
                HeaderData.Quotes data = HeaderData.parseQuotes(cache.getString("crypto_body", ""));
                quotes.setText(data.text());
                quotesInfo.setText(info("CoinGecko · USD", "crypto", data.observedAt,
                        HeaderData.stale(now, data.observedAt, HeaderData.CRYPTO_STALE)));
            } catch (JSONException error) {
                quotes.setText(R.string.header_quotes_empty);
                quotesInfo.setText(context.getString(R.string.header_provider_empty, "CoinGecko · USD"));
            }
        }
        if (weatherEnabled) {
            try {
                HeaderData.Weather data = HeaderData.parseWeather(cache.getString("weather_body", ""));
                String condition = context.getResources().getStringArray(R.array.header_weather_conditions)
                        [data.conditionIndex()];
                weather.setText(context.getString(R.string.header_weather_value,
                        context.getString(R.string.header_weather_city), data.celsius, condition));
                weatherInfo.setText(info("Open-Meteo", "weather", data.observedAt,
                        HeaderData.stale(now, data.observedAt, HeaderData.WEATHER_STALE)));
            } catch (JSONException error) {
                weather.setText(context.getString(R.string.header_weather_empty,
                        context.getString(R.string.header_weather_city)));
                weatherInfo.setText(context.getString(R.string.header_provider_empty, "Open-Meteo"));
            }
        }
    }

    private String info(String provider, String feed, long observedAt, boolean stale) {
        SimpleDateFormat time = new SimpleDateFormat("dd.MM HH:mm", Locale.getDefault());
        time.setTimeZone(TimeZone.getTimeZone("Asia/Krasnoyarsk"));
        String text = provider + " · " + time.format(new Date(observedAt));
        if (stale) return text + " · " + context.getString(R.string.header_stale);
        if (cache.getBoolean(feed + "_failed", false)) {
            return text + " · " + context.getString(R.string.header_update_failed);
        }
        return text;
    }

    @Override public void close() {
        stop();
        worker.shutdownNow();
    }
}
