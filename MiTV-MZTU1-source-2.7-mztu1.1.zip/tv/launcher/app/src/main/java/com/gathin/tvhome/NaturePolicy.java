package com.gathin.tvhome;

import java.util.Random;
import java.util.concurrent.TimeUnit;

/** A small curated landscape catalog; no search API, credentials or arbitrary download URLs. */
final class NaturePolicy {
    static final long INTERVAL = TimeUnit.HOURS.toMillis(1);
    static final int MAX_BYTES = 8 * 1024 * 1024;
    static final int WIDTH = 3840, HEIGHT = 2160;
    private static final String[] PHOTOS = {
            "photo-1470770841072-f978cf4d019e", // Mountain lake
            "photo-1464822759023-fed622ff2c3b", // Mountains
            "photo-1441974231531-c6227db76b6e", // Forest
            "photo-1501785888041-af3ef285b470", // Lake
            "photo-1433086966358-54859d0ed716", // Waterfall
            "photo-1469474968028-56623f02e42e"  // Mountain landscape
    };

    static int count() { return PHOTOS.length; }
    static boolean valid(int index) { return index >= 0 && index < count(); }

    static String url(int index) {
        requireIndex(index);
        return "https://images.unsplash.com/" + PHOTOS[index]
                + "?fm=jpg&fit=crop&w=3840&h=2160&q=80";
    }

    static String fileName(int index) {
        requireIndex(index);
        return PHOTOS[index] + ".jpg";
    }

    static boolean cacheName(String name) {
        for (int i = 0; i < count(); i++) if (fileName(i).equals(name)) return true;
        return false;
    }

    static int pick(int previous, Random random) {
        return valid(previous) ? (previous + 1 + random.nextInt(count() - 1)) % count()
                : random.nextInt(count());
    }

    static long delay(long now, boolean hasCache, long changed, long attempted, boolean failed) {
        if (failed) return HeaderData.delay(now, attempted, HeaderData.RETRY_INTERVAL);
        return hasCache ? HeaderData.delay(now, changed, INTERVAL) : 0;
    }

    private static void requireIndex(int index) {
        if (!valid(index)) throw new IllegalArgumentException("Unknown nature image");
    }
}
