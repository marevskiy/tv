# MiTV launcher

Custom Android TV launcher based on [CleanYourTV](https://github.com/Gathin23/cleanyourtv),
upstream revision `575d73f0f30c329aa7ebaea2bc863943fd9bf7f9` (version 2.7).
The upstream MIT license and Outfit font license are retained in `LICENSE` and
`launcher/FONT-LICENSE-OFL.txt`. This is a custom fork; it adds network access that the
upstream launcher intentionally does not have.

The six dock positions are Vokino, SmartTube, Kinopoisk, VK Video, Kick and VLC.
The left header shows BTC, ETH and LTC in USD; the right header shows current weather
in Krasnoyarsk, Russia (56.0153, 92.8932), in Celsius. Existing clocks, system buttons
and D-pad navigation remain in the original layout.

Nature wallpapers download automatically from a fixed six-photo Unsplash landscape
catalog and change once per hour while Home is visible. Downloads are 3840×2160 JPEGs;
the renderer samples them down to the screen size on a worker thread. A shade is painted
into the bitmap once for readable text. The last two validated images are retained in
private app storage (8 MiB maximum per download), so failures keep the current background.
Incomplete files never replace a valid cache entry. If Home is hidden, transfers and
timers stop; returning after several missed hours fetches at most one new picture.
Failures retry after five minutes. Photo source/license: [Unsplash](https://unsplash.com/license).
Image files are downloaded at runtime and are not included in this repository.

Quotes use the public [CoinGecko API](https://www.coingecko.com/en/api), at most once
every 15 minutes. Weather uses [Open-Meteo](https://open-meteo.com/), at most once every
30 minutes. No API keys are needed. Requests run on one worker while Home is resumed,
with HTTPS certificate verification, timeouts and a 32 KiB response limit. Failed feeds
retry after five minutes; a slow weather request does not delay displaying loaded quotes.
Detailed provider failures appear only in the app log. Leaving Home
cancels requests and scheduled refreshes; there is no background service or boot job.
Providers can rate-limit or refuse requests; live API responses still require validation
on the target network.

Last valid responses are cached in private app preferences. Provider observation dates
are displayed in the Krasnoyarsk time zone. Quotes older than 30 minutes and weather
older than one hour are marked outdated. A failure keeps cached values; no cached
response shows an unavailable placeholder, never an invented price or temperature.

`themes/mitv-mztu1/config.json` holds the dock preset. These two optional theme keys
can hide the corresponding header and stop its requests:

```json
{
  "show_crypto_quotes": false,
  "show_krasnoyarsk_weather": false,
  "auto_nature_wallpaper": false
}
```

Automatic nature also respects the existing Wallpaper picker: choose **None** to disable
it and its requests, or **Theme default** to resume. A manually chosen local wallpaper
takes precedence. `wallpaper_dim` controls additional dimming (20% for the nature preset).
Network destinations are `api.coingecko.com`, `api.open-meteo.com` and `images.unsplash.com`.

Build requirements: JDK 17, Android SDK platform 34 and build-tools 34.0.0. The Gradle
8.9 wrapper verifies its pinned distribution checksum. From `launcher/`:

```sh
./gradlew --no-daemon --max-workers=2 testReleaseUnitTest lintRelease assembleRelease
```

Windows uses the same command with `gradlew.bat`. The cloud environment's reusable
installation instructions configure its own writable SDK, JDK and Gradle cache outside
this checkout. Do not commit `local.properties`, APKs, signing keys, ADB keys, device
backups or screenshots.

Output: `launcher/app/build/outputs/apk/release/app-release.apk`, application ID
`com.gathin.tvhome`, version `2.7-mztu1.1` (10), signed with a local development key.
Keep that key locally to sign later updates; it is not part of this repository.

The inherited `build-and-install` scripts expect the upstream `tools/` directory and
can change the default Home or disable a stock launcher. They are preserved unchanged
for provenance; do not run them for this workflow. Installation and any Home handover
must be separate, reviewed steps after a package/settings backup, restore plan and
actual-device screenshots. Keep the existing Home and setup wizard enabled until the
replacement and Wi-Fi ownership have been checked. Building an APK does not prove
installation, the real remote's behavior, network access or visual layout on a TV.
