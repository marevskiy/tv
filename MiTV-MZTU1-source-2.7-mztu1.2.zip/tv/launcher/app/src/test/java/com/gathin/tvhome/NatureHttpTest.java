package com.gathin.tvhome;

import org.junit.Test;
import java.io.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import static org.junit.Assert.*;

public class NatureHttpTest {
    private long deadline() { return System.nanoTime() + TimeUnit.SECONDS.toNanos(20); }

    @Test public void copiesCompleteBodyWithoutTransformingIt() throws Exception {
        byte[] body = new byte[]{1, 2, 3, 4};
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        NatureHttp.copy(new ByteArrayInputStream(body), output, body.length, () -> true, deadline());
        assertArrayEquals(body, output.toByteArray());
    }

    @Test public void refusesEmptyAndTruncatedTransfers() {
        assertThrows(IOException.class, () -> NatureHttp.copy(new ByteArrayInputStream(new byte[0]),
                new ByteArrayOutputStream(), -1, () -> true, deadline()));
        assertThrows(IOException.class, () -> NatureHttp.copy(new ByteArrayInputStream(new byte[2]),
                new ByteArrayOutputStream(), 100, () -> true, deadline()));
    }

    @Test public void enforcesSizeLimitWhenServerOmitsLength() {
        InputStream infinite = new InputStream() {
            @Override public int read() { return 0; }
            @Override public int read(byte[] bytes) { return bytes.length; }
        };
        CountingOutput output = new CountingOutput();
        assertThrows(IOException.class,
                () -> NatureHttp.copy(infinite, output, -1, () -> true, deadline()));
        assertEquals(NaturePolicy.MAX_BYTES, output.bytes);
    }

    @Test public void oversizedDeclaredResponseWritesNothing() {
        CountingOutput output = new CountingOutput();
        assertThrows(IOException.class, () -> NatureHttp.copy(new ByteArrayInputStream(new byte[10]),
                output, NaturePolicy.MAX_BYTES + 1L, () -> true, deadline()));
        assertEquals(0, output.bytes);
    }

    @Test public void cancellationStopsWritingFurtherChunks() {
        AtomicBoolean visible = new AtomicBoolean(true);
        CountingOutput output = new CountingOutput() {
            @Override public void write(byte[] bytes, int off, int length) {
                super.write(bytes, off, length);
                visible.set(false);
            }
        };
        assertThrows(InterruptedIOException.class, () -> NatureHttp.copy(
                new ByteArrayInputStream(new byte[32_000]), output, 32_000, visible::get, deadline()));
        assertEquals(8192, output.bytes);
    }

    @Test public void expiredDeadlineWritesNothing() {
        CountingOutput output = new CountingOutput();
        assertThrows(InterruptedIOException.class, () -> NatureHttp.copy(new ByteArrayInputStream(new byte[1]),
                output, 1, () -> true, System.nanoTime() - 1));
        assertEquals(0, output.bytes);
    }

    @Test public void hiddenHomeDoesNotStartAConnection() {
        assertThrows(InterruptedIOException.class,
                () -> new NatureHttp().download(0, new File("unused.part"), () -> false));
    }

    private static class CountingOutput extends OutputStream {
        int bytes;
        @Override public void write(int value) { bytes++; }
        @Override public void write(byte[] values, int off, int length) { bytes += length; }
    }
}
