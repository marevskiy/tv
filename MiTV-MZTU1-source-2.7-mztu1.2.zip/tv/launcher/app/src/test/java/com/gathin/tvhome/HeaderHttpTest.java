package com.gathin.tvhome;

import org.junit.Test;

import java.io.IOException;
import java.io.InterruptedIOException;

import static org.junit.Assert.assertThrows;

public class HeaderHttpTest {
    @Test public void refusesArbitraryDestinationsBeforeOpeningAConnection() {
        assertThrows(IOException.class, () -> new HeaderHttp().get("https://example.com/", () -> true));
    }

    @Test public void hiddenHomeDoesNotOpenAProviderConnection() {
        assertThrows(InterruptedIOException.class,
                () -> new HeaderHttp().get(HeaderHttp.QUOTES_URL, () -> false));
    }
}
