package com.gathin.tvhome;

import org.json.JSONException;
import org.junit.Test;
import static org.junit.Assert.*;

public class MetWeatherTest {
    private static final long FETCHED = 1_792_927_800_000L; // 2026-10-25T11:30Z
    private static final String TIME = "2026-10-25T11:00:00Z";

    @Test public void readsCelsiusAndUtcForecastHour() throws Exception {
        HeaderData.Weather weather = parse("partlycloudy_day", -2.8);
        assertEquals(-2.8, weather.celsius, .001);
        assertEquals(2, weather.conditionIndex());
        assertEquals(1_792_926_000_000L, weather.observedAt);
    }

    @Test public void mapsNightAndSevereConditions() throws Exception {
        assertEquals(1, parse("fair_night", 4).conditionIndex());
        assertEquals(11, parse("heavyrainandthunder", 4).conditionIndex());
        assertEquals(13, parse("sleet", -1).conditionIndex());
        assertEquals(10, parse("lightsnowshowers_day", -5).conditionIndex());
        assertEquals(12, parse("unknowncondition", 3).conditionIndex());
    }

    @Test public void choosesCurrentHourInsteadOfFutureForecast() throws Exception {
        String json = wrap(entry("2026-10-25T10:00:00Z", "cloudy", -4) + ","
                + entry(TIME, "fair_day", -2) + "," + entry("2026-10-25T12:00:00Z", "clearsky_day", 1));
        HeaderData.Weather weather = HeaderData.parseMetWeather(json, FETCHED);
        assertEquals(-2, weather.celsius, .001);
        assertTrue(HeaderData.stale(FETCHED + 2 * 3_600_000L,
                weather.observedAt, HeaderData.WEATHER_STALE));
        // Reading this cached response at its saved fetch time still selects the old hour.
        assertEquals(weather.observedAt, HeaderData.parseMetWeather(json, FETCHED).observedAt);
    }

    @Test public void supportsSixHourSummaryWhenOneHourIsMissing() throws Exception {
        String json = wrap(entry(TIME, "snow", -8)).replace("next_1_hours", "next_6_hours");
        assertEquals(8, HeaderData.parseMetWeather(json, FETCHED).conditionIndex());
    }

    @Test public void rejectsWrongUnitsEmptyForecastAndInvalidTimestamp() {
        assertThrows(JSONException.class, () -> HeaderData.parseMetWeather(
                wrap(entry(TIME, "cloudy", 30)).replace("celsius", "fahrenheit"), FETCHED));
        assertThrows(JSONException.class, () -> HeaderData.parseMetWeather(wrap(""), FETCHED));
        assertThrows(JSONException.class, () -> HeaderData.parseMetWeather(
                wrap(entry("not-a-date", "cloudy", 2)), FETCHED));
    }

    @Test public void rejectsInvalidTemperatureAndMissingFetchTime() {
        assertThrows(JSONException.class, () -> parse("cloudy", -150));
        assertThrows(JSONException.class, () -> HeaderData.parseMetWeather(
                wrap(entry(TIME, "cloudy", 3)), 0));
    }

    private static HeaderData.Weather parse(String symbol, double temperature) throws JSONException {
        return HeaderData.parseMetWeather(wrap(entry(TIME, symbol, temperature)), FETCHED);
    }

    private static String wrap(String entries) {
        return "{\"properties\":{\"meta\":{\"units\":{\"air_temperature\":\"celsius\"}},"
                + "\"timeseries\":[" + entries + "]}}";
    }

    private static String entry(String time, String symbol, double temperature) {
        return "{\"time\":\"" + time + "\",\"data\":{\"instant\":{\"details\":{\"air_temperature\":"
                + temperature + "}},\"next_1_hours\":{\"summary\":{\"symbol_code\":\"" + symbol + "\"}}}}";
    }
}
