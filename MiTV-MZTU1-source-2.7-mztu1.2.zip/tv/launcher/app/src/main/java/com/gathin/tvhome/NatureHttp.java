package com.gathin.tvhome;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.io.OutputStream;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BooleanSupplier;

import javax.net.ssl.HttpsURLConnection;

/** Streams one fixed-catalog JPEG to a temporary file without buffering a 4K image in the heap. */
final class NatureHttp {
    private final AtomicReference<HttpsURLConnection> pending = new AtomicReference<>();

    void download(int index, File temporary, BooleanSupplier current) throws IOException {
        String endpoint = NaturePolicy.url(index);
        long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(30);
        check(current, deadline);
        HttpsURLConnection connection = (HttpsURLConnection) new URL(endpoint).openConnection();
        pending.set(connection);
        try {
            check(current, deadline);
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(10000);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("Accept", "image/jpeg");
            connection.setRequestProperty("User-Agent", "MarevskiyTV/1.1");
            int status = connection.getResponseCode();
            if (status != 200) throw new IOException("Wallpaper provider returned HTTP " + status);
            long expected = connection.getContentLengthLong();
            if (expected > NaturePolicy.MAX_BYTES) throw new IOException("Wallpaper exceeds size limit");
            String type = connection.getContentType();
            if (type != null && !"image/jpeg".equalsIgnoreCase(type.split(";", 2)[0].trim())) {
                throw new IOException("Wallpaper is not a JPEG");
            }
            try (InputStream input = connection.getInputStream();
                 FileOutputStream output = new FileOutputStream(temporary)) {
                copy(input, output, expected, current, deadline);
            }
        } finally {
            pending.compareAndSet(connection, null);
            connection.disconnect();
        }
    }

    static void copy(InputStream input, OutputStream output, long expected,
                     BooleanSupplier current, long deadline) throws IOException {
        if (expected > NaturePolicy.MAX_BYTES) throw new IOException("Wallpaper exceeds size limit");
        int written = 0;
        byte[] buffer = new byte[8192];
        while (true) {
            check(current, deadline);
            int count = input.read(buffer);
            if (count == -1) break;
            check(current, deadline);
            written += count;
            if (written > NaturePolicy.MAX_BYTES) throw new IOException("Wallpaper exceeds size limit");
            output.write(buffer, 0, count);
        }
        check(current, deadline);
        if (written == 0 || (expected >= 0 && written != expected)) {
            throw new IOException("Incomplete wallpaper response");
        }
    }

    private static void check(BooleanSupplier current, long deadline) throws InterruptedIOException {
        if (!current.getAsBoolean() || Thread.currentThread().isInterrupted()) {
            throw new InterruptedIOException("Home no longer visible");
        }
        if (System.nanoTime() - deadline >= 0) throw new InterruptedIOException("Wallpaper deadline exceeded");
    }

    void cancel() {
        HttpsURLConnection connection = pending.getAndSet(null);
        if (connection != null) connection.disconnect();
    }
}
