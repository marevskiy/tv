package com.gathin.tvhome;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;

import java.text.NumberFormat;
import java.time.Instant;
import java.time.DateTimeException;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/** Validated provider data and cache timing; independent of Android and the network. */
final class HeaderData {
    static final long CRYPTO_INTERVAL = TimeUnit.MINUTES.toMillis(15);
    static final long WEATHER_INTERVAL = TimeUnit.MINUTES.toMillis(30);
    static final long RETRY_INTERVAL = TimeUnit.MINUTES.toMillis(5);
    static final long CRYPTO_STALE = TimeUnit.MINUTES.toMillis(30);
    static final long WEATHER_STALE = TimeUnit.HOURS.toMillis(1);
    private static final long CLOCK_TOLERANCE = TimeUnit.MINUTES.toMillis(5);

    static final class Quotes {
        final double btc, eth, ltc;
        final long observedAt;

        Quotes(double btc, double eth, double ltc, long observedAt) {
            this.btc = btc;
            this.eth = eth;
            this.ltc = ltc;
            this.observedAt = observedAt;
        }

        String text() {
            NumberFormat usd = NumberFormat.getCurrencyInstance(Locale.US);
            return "BTC " + usd.format(btc) + "   ·   ETH " + usd.format(eth)
                    + "   ·   LTC " + usd.format(ltc);
        }
    }

    static final class Weather {
        final double celsius;
        final int code;
        final long observedAt;

        Weather(double celsius, int code, long observedAt) {
            this.celsius = celsius;
            this.code = code;
            this.observedAt = observedAt;
        }

        /** Index in header_weather_conditions, following the WMO interpretation codes. */
        int conditionIndex() {
            switch (code) {
                case 0: return 0;
                case 1: return 1;
                case 2: return 2;
                case 3: return 3;
                case 45: case 48: return 4;
                case 51: case 53: case 55: return 5;
                case 56: case 57: case 66: case 67: return 6;
                case 68: case 69: return 13;
                case 61: case 63: case 65: return 7;
                case 71: case 73: case 75: case 77: return 8;
                case 80: case 81: case 82: return 9;
                case 85: case 86: return 10;
                case 95: case 96: case 99: return 11;
                default: return 12;
            }
        }
    }

    static Quotes parseQuotes(String body) throws JSONException {
        JSONObject root = new JSONObject(body);
        JSONObject btc = root.getJSONObject("bitcoin");
        JSONObject eth = root.getJSONObject("ethereum");
        JSONObject ltc = root.getJSONObject("litecoin");
        long oldest = Math.min(timestamp(btc, "last_updated_at"),
                Math.min(timestamp(eth, "last_updated_at"), timestamp(ltc, "last_updated_at")));
        return new Quotes(price(btc), price(eth), price(ltc), oldest);
    }

    static Weather parseWeather(String body) throws JSONException {
        JSONObject current = new JSONObject(body).getJSONObject("current");
        double temp = number(current, "temperature_2m");
        double code = number(current, "weather_code");
        if (temp < -100 || temp > 70 || code < 0 || code > 99 || code != Math.rint(code)) {
            throw new JSONException("Invalid current weather");
        }
        return new Weather(temp, (int) code, timestamp(current, "time"));
    }

    /** Select the forecast hour at fetch time; reusing a cache must not advance its apparent freshness. */
    static Weather parseMetWeather(String body, long fetchedAt) throws JSONException {
        if (fetchedAt < 1_500_000_000_000L) throw new JSONException("Missing weather fetch time");
        JSONObject properties = new JSONObject(body).getJSONObject("properties");
        String units = properties.getJSONObject("meta").getJSONObject("units").getString("air_temperature");
        if (!"celsius".equals(units)) throw new JSONException("Expected Celsius forecast");
        JSONArray series = properties.getJSONArray("timeseries");
        JSONObject selected = null;
        long selectedTime = Long.MIN_VALUE;
        JSONObject future = null;
        long futureTime = Long.MAX_VALUE;
        for (int i = 0; i < series.length(); i++) {
            JSONObject entry = series.getJSONObject(i);
            long time = metTime(entry.getString("time"));
            if (time <= fetchedAt && time > selectedTime) { selected = entry; selectedTime = time; }
            if (time > fetchedAt && time < futureTime) { future = entry; futureTime = time; }
        }
        if (selected == null) { selected = future; selectedTime = futureTime; }
        if (selected == null) throw new JSONException("Empty forecast");
        JSONObject data = selected.getJSONObject("data");
        double temp = number(data.getJSONObject("instant").getJSONObject("details"), "air_temperature");
        if (temp < -100 || temp > 70) throw new JSONException("Invalid forecast temperature");
        JSONObject next = data.optJSONObject("next_1_hours");
        if (next == null) next = data.optJSONObject("next_6_hours");
        JSONObject summary = next == null ? null : next.optJSONObject("summary");
        String symbol = summary == null ? "" : summary.optString("symbol_code", "");
        return new Weather(temp, metCode(symbol), selectedTime);
    }

    private static long metTime(String value) throws JSONException {
        try {
            long time = Instant.parse(value).toEpochMilli();
            if (time < 1_500_000_000_000L || time > 10_000_000_000_000L) throw new JSONException("Invalid forecast date");
            return time;
        } catch (DateTimeException | ArithmeticException error) {
            throw new JSONException("Invalid forecast date");
        }
    }

    private static int metCode(String raw) {
        String symbol = raw.replaceAll("_(day|night|polartwilight)$", "");
        if (symbol.contains("thunder")) return 95;
        if (symbol.contains("sleet")) return 68;
        if (symbol.contains("snow")) return symbol.contains("showers") ? 85 : 73;
        if (symbol.contains("rain")) return symbol.contains("showers") ? 80 : 63;
        switch (symbol) {
            case "clearsky": return 0;
            case "fair": return 1;
            case "partlycloudy": return 2;
            case "cloudy": return 3;
            case "fog": return 45;
            default: return -1;
        }
    }

    private static double price(JSONObject object) throws JSONException {
        double value = number(object, "usd");
        if (value <= 0) throw new JSONException("Invalid USD quote");
        return value;
    }

    private static double number(JSONObject object, String key) throws JSONException {
        Object raw = object.get(key);
        if (!(raw instanceof Number)) throw new JSONException("Expected numeric " + key);
        double value = ((Number) raw).doubleValue();
        if (!Double.isFinite(value)) throw new JSONException("Non-finite " + key);
        return value;
    }

    private static long timestamp(JSONObject object, String key) throws JSONException {
        double seconds = number(object, key);
        // Provider requests use Unix seconds. Reject milliseconds, fractions and corrupt cache values.
        if (seconds < 1_500_000_000L || seconds > 10_000_000_000L || seconds != Math.rint(seconds)) {
            throw new JSONException("Invalid provider timestamp");
        }
        return (long) seconds * 1000L;
    }

    static boolean stale(long now, long observedAt, long maxAge) {
        return observedAt <= 0 || observedAt > now + CLOCK_TOLERANCE || now - observedAt > maxAge;
    }

    static long delay(long now, long lastAttempt, long interval) {
        // A reset TV clock must neither freeze refresh forever nor produce a negative delay.
        if (lastAttempt <= 0 || now < lastAttempt || now - lastAttempt >= interval) return 0;
        return interval - (now - lastAttempt);
    }

    static long refreshDelay(long now, long lastAttempt, long interval, boolean failed) {
        return delay(now, lastAttempt, failed ? RETRY_INTERVAL : interval);
    }
}
