package com.gathin.tvhome;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.function.Consumer;

/** Hourly nature downloads only while Home is resumed, retaining the last two validated JPEGs. */
final class NatureWallpaper implements AutoCloseable {
    private static final String TAG = "TvHome.Nature";
    private final File directory;
    private final SharedPreferences cache;
    private final Consumer<File> display;
    private final boolean enabled;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final NatureHttp http = new NatureHttp();
    private final Random random = new Random();
    private volatile boolean active;
    private volatile int generation;
    private Future<?> request;
    private final Runnable tick = this::refresh;

    NatureWallpaper(Context context, boolean enabled, Consumer<File> display) {
        this.enabled = enabled;
        this.display = display;
        directory = new File(context.getFilesDir(), "nature-wallpapers");
        cache = context.getSharedPreferences("nature_wallpapers", Context.MODE_PRIVATE);
        if (!"github_3d9cba6".equals(cache.getString("source", ""))) {
            // A source change retries promptly, keeping any previously validated photographs.
            cache.edit().putString("source", "github_3d9cba6").remove("attempted")
                    .putBoolean("failed", false).apply();
        }
    }

    void start() {
        if (active || !enabled) return;
        active = true;
        generation++;
        File last = cachedFile();
        if (last != null) display.accept(last);
        main.post(tick);
    }

    void stop() {
        active = false;
        generation++;
        main.removeCallbacks(tick);
        if (request != null) request.cancel(true);
        http.cancel();
    }

    private boolean current(int token) { return active && generation == token; }

    private File cachedFile() {
        int index = cache.getInt("image", -1);
        if (!NaturePolicy.valid(index)) return null;
        File file = new File(directory, NaturePolicy.fileName(index));
        return file.isFile() && file.length() > 0 && file.length() <= NaturePolicy.MAX_BYTES ? file : null;
    }

    private long delay() {
        return NaturePolicy.delay(System.currentTimeMillis(), cachedFile() != null,
                cache.getLong("changed", 0), cache.getLong("attempted", 0),
                cache.getBoolean("failed", false));
    }

    private void refresh() {
        if (!active) return;
        if (delay() > 0) {
            schedule();
            return;
        }
        int token = generation;
        request = worker.submit(() -> {
            File temporary = null;
            File result = null;
            try {
                if (!current(token)) return;
                if (!directory.isDirectory() && !directory.mkdirs()) throw new IOException("Cannot create nature cache");
                int previous = cache.getInt("image", -1);
                cleanup(previous, cache.getInt("previous", -1));
                int index = NaturePolicy.pick(previous, random);
                temporary = File.createTempFile("download-", ".part", directory);
                http.download(index, temporary, () -> current(token));
                validate(temporary);
                if (!current(token)) return;
                File destination = new File(directory, NaturePolicy.fileName(index));
                try {
                    Files.move(temporary.toPath(), destination.toPath(),
                            StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
                } catch (AtomicMoveNotSupportedException unsupported) {
                    Files.move(temporary.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING);
                }
                long now = System.currentTimeMillis();
                cache.edit().putInt("previous", previous).putInt("image", index)
                        .putLong("changed", now).putLong("attempted", now).putBoolean("failed", false).apply();
                result = destination;
                cleanup(index, previous);
            } catch (IOException | RuntimeException | OutOfMemoryError error) {
                if (current(token)) {
                    Log.w(TAG, "Cannot refresh nature wallpaper", error);
                    cache.edit().putLong("attempted", System.currentTimeMillis()).putBoolean("failed", true).apply();
                }
            } finally {
                if (temporary != null && temporary.exists() && !temporary.delete()) {
                    Log.w(TAG, "Cannot remove incomplete wallpaper");
                }
                File ready = result;
                main.post(() -> {
                    if (current(token)) {
                        if (ready != null) display.accept(ready);
                        schedule();
                    }
                });
            }
        });
    }

    /** Validate full 4K dimensions and a tiny decoded sample before replacing any cached picture. */
    private static void validate(File file) throws IOException {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getPath(), bounds);
        if (bounds.outWidth != NaturePolicy.WIDTH || bounds.outHeight != NaturePolicy.HEIGHT
                || !"image/jpeg".equals(bounds.outMimeType)) throw new IOException("Expected a 3840x2160 JPEG");
        BitmapFactory.Options sample = new BitmapFactory.Options();
        sample.inSampleSize = 32;
        sample.inPreferredConfig = Bitmap.Config.RGB_565;
        Bitmap decoded = BitmapFactory.decodeFile(file.getPath(), sample);
        if (decoded == null) throw new IOException("Unreadable wallpaper JPEG");
        decoded.recycle();
    }

    private void cleanup(int current, int previous) {
        File[] files = directory.listFiles();
        if (files == null) return;
        for (File file : files) {
            String name = file.getName();
            boolean keep = NaturePolicy.valid(current) && name.equals(NaturePolicy.fileName(current));
            keep |= NaturePolicy.valid(previous) && name.equals(NaturePolicy.fileName(previous));
            boolean owned = NaturePolicy.cacheName(name) || (name.startsWith("download-") && name.endsWith(".part"));
            if (owned && !keep && file.isFile() && !file.delete()) Log.w(TAG, "Cannot prune nature cache");
        }
    }

    private void schedule() {
        if (!active) return;
        main.removeCallbacks(tick);
        main.postDelayed(tick, Math.max(1000L, delay()));
    }

    @Override public void close() {
        stop();
        worker.shutdownNow();
    }
}
