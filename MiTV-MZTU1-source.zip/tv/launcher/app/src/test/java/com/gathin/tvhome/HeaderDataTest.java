package com.gathin.tvhome;

import org.json.JSONException;
import org.junit.Test;

import java.util.Locale;

import static org.junit.Assert.*;

public class HeaderDataTest {
    private static final long NOW = 1_792_922_400_000L;
    private static final String QUOTES = "{\"bitcoin\":{\"usd\":101234.56,\"last_updated_at\":1792922400},"
            + "\"ethereum\":{\"usd\":3123.45,\"last_updated_at\":1792922300},"
            + "\"litecoin\":{\"usd\":87.65,\"last_updated_at\":1792922350}}";

    @Test public void parsesAllThreeUsdPricesAndUsesOldestProviderTimestamp() throws Exception {
        HeaderData.Quotes data = HeaderData.parseQuotes(QUOTES);
        assertEquals(101234.56, data.btc, 0.001);
        assertEquals(3123.45, data.eth, 0.001);
        assertEquals(87.65, data.ltc, 0.001);
        assertEquals(1_792_922_300_000L, data.observedAt);
    }

    @Test public void showsUsdEvenWhenTheTvLocaleIsRussian() throws Exception {
        Locale before = Locale.getDefault();
        try {
            Locale.setDefault(new Locale("ru", "RU"));
            assertEquals("BTC $101,234.56   ·   ETH $3,123.45   ·   LTC $87.65",
                    HeaderData.parseQuotes(QUOTES).text());
        } finally {
            Locale.setDefault(before);
        }
    }

    @Test public void rejectsMissingCoinAndProviderErrorInsteadOfInventingZero() {
        assertThrows(JSONException.class, () -> HeaderData.parseQuotes("{}"));
        assertThrows(JSONException.class, () -> HeaderData.parseQuotes("{\"error\":\"rate limit\"}"));
        assertThrows(JSONException.class, () -> HeaderData.parseQuotes(
                QUOTES.replace("\"usd\":87.65", "\"usd\":null")));
    }

    @Test public void rejectsNonPositiveOrNonNumericPrices() {
        for (String value : new String[]{"0", "-12", "\"NaN\"", "\"87.65\""}) {
            assertThrows(JSONException.class, () -> HeaderData.parseQuotes(
                    QUOTES.replace("\"usd\":87.65", "\"usd\":" + value)));
        }
    }

    @Test public void rejectsWrongTimestampUnitsAndFractions() {
        assertThrows(JSONException.class, () -> HeaderData.parseQuotes(
                QUOTES.replace("1792922350", "1792922350000")));
        assertThrows(JSONException.class, () -> HeaderData.parseQuotes(
                QUOTES.replace("1792922350", "1792922350.5")));
    }

    @Test public void parsesSiberianWinterTemperatureAndSnowCode() throws Exception {
        HeaderData.Weather data = HeaderData.parseWeather(weather(-34.5, 73));
        assertEquals(-34.5, data.celsius, 0.001);
        assertEquals(73, data.code);
        assertEquals(8, data.conditionIndex());
        assertEquals(NOW, data.observedAt);
    }

    @Test public void handlesSevereWeatherAndUnknownConditionsWithoutCallingThemClear() throws Exception {
        assertEquals(6, HeaderData.parseWeather(weather(-3, 67)).conditionIndex());
        assertEquals(11, HeaderData.parseWeather(weather(17, 99)).conditionIndex());
        assertEquals(12, HeaderData.parseWeather(weather(2, 20)).conditionIndex());
    }

    @Test public void rejectsInvalidWeatherRatherThanDisplayingMisleadingValues() {
        assertThrows(JSONException.class, () -> HeaderData.parseWeather(weather(-150, 0)));
        assertThrows(JSONException.class, () -> HeaderData.parseWeather(weather(100, 0)));
        assertThrows(JSONException.class, () -> HeaderData.parseWeather(weather(5, 2.5)));
        assertThrows(JSONException.class, () -> HeaderData.parseWeather("{\"current\":null}"));
    }

    @Test public void marksOldOrImplausiblyFutureSourceDataAsStale() {
        assertFalse(HeaderData.stale(NOW, NOW - HeaderData.CRYPTO_STALE, HeaderData.CRYPTO_STALE));
        assertTrue(HeaderData.stale(NOW, NOW - HeaderData.CRYPTO_STALE - 1, HeaderData.CRYPTO_STALE));
        assertTrue(HeaderData.stale(NOW, 0, HeaderData.CRYPTO_STALE));
        assertTrue(HeaderData.stale(NOW, NOW + 6 * 60_000, HeaderData.CRYPTO_STALE));
        assertTrue(HeaderData.stale(NOW, NOW - 25 * 3_600_000, HeaderData.WEATHER_STALE));
    }

    @Test public void frequentHomeVisitsDoNotTriggerFrequentRequests() {
        assertEquals(0, HeaderData.delay(NOW, 0, HeaderData.CRYPTO_INTERVAL));
        assertEquals(HeaderData.CRYPTO_INTERVAL, HeaderData.delay(NOW, NOW, HeaderData.CRYPTO_INTERVAL));
        assertEquals(HeaderData.CRYPTO_INTERVAL - 60_000,
                HeaderData.delay(NOW + 60_000, NOW, HeaderData.CRYPTO_INTERVAL));
        assertEquals(0, HeaderData.delay(NOW + HeaderData.CRYPTO_INTERVAL, NOW, HeaderData.CRYPTO_INTERVAL));
        assertEquals(HeaderData.WEATHER_INTERVAL - HeaderData.CRYPTO_INTERVAL,
                HeaderData.delay(NOW + HeaderData.CRYPTO_INTERVAL, NOW, HeaderData.WEATHER_INTERVAL));
    }

    @Test public void clockResetCannotPostponeUpdatesIndefinitely() {
        assertEquals(0, HeaderData.delay(NOW - 3_600_000, NOW, HeaderData.CRYPTO_INTERVAL));
    }

    private static String weather(double temperature, double code) {
        return "{\"current\":{\"time\":1792922400,\"temperature_2m\":" + temperature
                + ",\"weather_code\":" + code + "}}";
    }
}
