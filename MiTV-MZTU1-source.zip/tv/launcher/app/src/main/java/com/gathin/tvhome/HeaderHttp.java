package com.gathin.tvhome;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;

import javax.net.ssl.HttpsURLConnection;

/** Fixed HTTPS providers, ordinary platform certificate verification, and bounded requests. */
final class HeaderHttp {
    static final String QUOTES_URL = "https://api.coingecko.com/api/v3/simple/price"
            + "?ids=bitcoin,ethereum,litecoin&vs_currencies=usd&include_last_updated_at=true";
    static final String WEATHER_URL = "https://api.open-meteo.com/v1/forecast"
            + "?latitude=56.0153&longitude=92.8932&current=temperature_2m,weather_code"
            + "&temperature_unit=celsius&timeformat=unixtime&timezone=Asia%2FKrasnoyarsk";
    private static final int MAX_BYTES = 32 * 1024;
    private final AtomicReference<HttpsURLConnection> pending = new AtomicReference<>();

    String get(String endpoint, BooleanSupplier current) throws IOException {
        if (!QUOTES_URL.equals(endpoint) && !WEATHER_URL.equals(endpoint)) {
            throw new IOException("Unknown provider");
        }
        checkCurrent(current);
        long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(12);
        HttpsURLConnection connection = (HttpsURLConnection) new URL(endpoint).openConnection();
        pending.set(connection);
        try {
            checkCurrent(current);
            connection.setConnectTimeout(6000);
            connection.setReadTimeout(6000);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("User-Agent", "MarevskiyTV/1.0");
            if (connection.getResponseCode() != 200) throw new IOException("Provider unavailable");
            checkDeadline(deadline);
            if (connection.getContentLengthLong() > MAX_BYTES) throw new IOException("Response too large");
            try (InputStream input = connection.getInputStream();
                 ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[4096];
                int count;
                while ((count = input.read(buffer)) != -1) {
                    checkCurrent(current);
                    checkDeadline(deadline);
                    if (output.size() + count > MAX_BYTES) throw new IOException("Response too large");
                    output.write(buffer, 0, count);
                }
                checkCurrent(current);
                return new String(output.toByteArray(), StandardCharsets.UTF_8);
            }
        } finally {
            pending.compareAndSet(connection, null);
            connection.disconnect();
        }
    }

    private static void checkCurrent(BooleanSupplier current) throws InterruptedIOException {
        if (!current.getAsBoolean() || Thread.currentThread().isInterrupted()) {
            throw new InterruptedIOException("Home no longer visible");
        }
    }

    private static void checkDeadline(long deadline) throws InterruptedIOException {
        if (System.nanoTime() - deadline >= 0) throw new InterruptedIOException("Request deadline exceeded");
    }

    void cancel() {
        HttpsURLConnection connection = pending.getAndSet(null);
        if (connection != null) connection.disconnect();
    }
}
