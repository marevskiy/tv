package com.gathin.tvhome;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/** Validated provider data and cache timing; independent of Android and the network. */
final class HeaderData {
    static final long CRYPTO_INTERVAL = TimeUnit.MINUTES.toMillis(15);
    static final long WEATHER_INTERVAL = TimeUnit.MINUTES.toMillis(30);
    static final long CRYPTO_STALE = TimeUnit.MINUTES.toMillis(30);
    static final long WEATHER_STALE = TimeUnit.HOURS.toMillis(1);
    private static final long CLOCK_TOLERANCE = TimeUnit.MINUTES.toMillis(5);

    static final class Quotes {
        final double btc, eth, ltc;
        final long observedAt;

        Quotes(double btc, double eth, double ltc, long observedAt) {
            this.btc = btc;
            this.eth = eth;
            this.ltc = ltc;
            this.observedAt = observedAt;
        }

        String text() {
            NumberFormat usd = NumberFormat.getCurrencyInstance(Locale.US);
            return "BTC " + usd.format(btc) + "   ·   ETH " + usd.format(eth)
                    + "   ·   LTC " + usd.format(ltc);
        }
    }

    static final class Weather {
        final double celsius;
        final int code;
        final long observedAt;

        Weather(double celsius, int code, long observedAt) {
            this.celsius = celsius;
            this.code = code;
            this.observedAt = observedAt;
        }

        /** Index in header_weather_conditions, following the WMO interpretation codes. */
        int conditionIndex() {
            switch (code) {
                case 0: return 0;
                case 1: return 1;
                case 2: return 2;
                case 3: return 3;
                case 45: case 48: return 4;
                case 51: case 53: case 55: return 5;
                case 56: case 57: case 66: case 67: return 6;
                case 61: case 63: case 65: return 7;
                case 71: case 73: case 75: case 77: return 8;
                case 80: case 81: case 82: return 9;
                case 85: case 86: return 10;
                case 95: case 96: case 99: return 11;
                default: return 12;
            }
        }
    }

    static Quotes parseQuotes(String body) throws JSONException {
        JSONObject root = new JSONObject(body);
        JSONObject btc = root.getJSONObject("bitcoin");
        JSONObject eth = root.getJSONObject("ethereum");
        JSONObject ltc = root.getJSONObject("litecoin");
        long oldest = Math.min(timestamp(btc, "last_updated_at"),
                Math.min(timestamp(eth, "last_updated_at"), timestamp(ltc, "last_updated_at")));
        return new Quotes(price(btc), price(eth), price(ltc), oldest);
    }

    static Weather parseWeather(String body) throws JSONException {
        JSONObject current = new JSONObject(body).getJSONObject("current");
        double temp = number(current, "temperature_2m");
        double code = number(current, "weather_code");
        if (temp < -100 || temp > 70 || code < 0 || code > 99 || code != Math.rint(code)) {
            throw new JSONException("Invalid current weather");
        }
        return new Weather(temp, (int) code, timestamp(current, "time"));
    }

    private static double price(JSONObject object) throws JSONException {
        double value = number(object, "usd");
        if (value <= 0) throw new JSONException("Invalid USD quote");
        return value;
    }

    private static double number(JSONObject object, String key) throws JSONException {
        Object raw = object.get(key);
        if (!(raw instanceof Number)) throw new JSONException("Expected numeric " + key);
        double value = ((Number) raw).doubleValue();
        if (!Double.isFinite(value)) throw new JSONException("Non-finite " + key);
        return value;
    }

    private static long timestamp(JSONObject object, String key) throws JSONException {
        double seconds = number(object, key);
        // Provider requests use Unix seconds. Reject milliseconds, fractions and corrupt cache values.
        if (seconds < 1_500_000_000L || seconds > 10_000_000_000L || seconds != Math.rint(seconds)) {
            throw new JSONException("Invalid provider timestamp");
        }
        return (long) seconds * 1000L;
    }

    static boolean stale(long now, long observedAt, long maxAge) {
        return observedAt <= 0 || observedAt > now + CLOCK_TOLERANCE || now - observedAt > maxAge;
    }

    static long delay(long now, long lastAttempt, long interval) {
        // A reset TV clock must neither freeze refresh forever nor produce a negative delay.
        if (lastAttempt <= 0 || now < lastAttempt || now - lastAttempt >= interval) return 0;
        return interval - (now - lastAttempt);
    }
}
