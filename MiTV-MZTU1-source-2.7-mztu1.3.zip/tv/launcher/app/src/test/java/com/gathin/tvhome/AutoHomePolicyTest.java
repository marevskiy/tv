package com.gathin.tvhome;

import org.junit.Test;
import static org.junit.Assert.*;

public class AutoHomePolicyTest {
    private static final String ACTION = "android.intent.action.BOOT_COMPLETED";
    private static final String OWN = "com.gathin.tvhome";

    @Test public void startsOnCompletedBootWhenSelectedHome() {
        assertTrue(AutoHomePolicy.shouldStart(ACTION, OWN, OWN));
    }
    @Test public void restoredStockHomeIsRespected() {
        assertFalse(AutoHomePolicy.shouldStart(ACTION, "com.google.android.tvlauncher", OWN));
    }
    @Test public void chooserOrUnresolvedHomeIsNotOverridden() {
        assertFalse(AutoHomePolicy.shouldStart(ACTION, null, OWN));
        assertFalse(AutoHomePolicy.shouldStart(ACTION, "android", OWN));
    }
    @Test public void unrelatedBroadcastDoesNotOpenHome() {
        assertFalse(AutoHomePolicy.shouldStart(null, OWN, OWN));
        assertFalse(AutoHomePolicy.shouldStart("android.intent.action.SCREEN_ON", OWN, OWN));
        assertFalse(AutoHomePolicy.shouldStart("android.intent.action.MY_PACKAGE_REPLACED", OWN, OWN));
    }
}
