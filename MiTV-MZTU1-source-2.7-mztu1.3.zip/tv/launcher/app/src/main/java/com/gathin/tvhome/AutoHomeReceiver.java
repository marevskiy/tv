package com.gathin.tvhome;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.util.Log;

/** One ordinary boot callback: no service, key filter, polling or vendor component changes. */
public final class AutoHomeReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        ResolveInfo home = context.getPackageManager().resolveActivity(new Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY);
        String owner = home == null || home.activityInfo == null ? null : home.activityInfo.packageName;
        if (!AutoHomePolicy.shouldStart(intent.getAction(), owner, context.getPackageName())) return;
        try {
            context.startActivity(new Intent(context, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED));
            Log.i("TvHome.Boot", "Requested selected Home after boot");
        } catch (RuntimeException error) {
            Log.w("TvHome.Boot", "Cannot start selected Home after boot", error);
        }
    }
}
