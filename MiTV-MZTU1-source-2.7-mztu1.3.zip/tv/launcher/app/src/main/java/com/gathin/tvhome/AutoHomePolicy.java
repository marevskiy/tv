package com.gathin.tvhome;

/** A boot hook must stop applying as soon as the user restores another default Home. */
final class AutoHomePolicy {
    static boolean shouldStart(String action, String defaultPackage, String ownPackage) {
        return "android.intent.action.BOOT_COMPLETED".equals(action)
                && ownPackage != null && ownPackage.equals(defaultPackage);
    }
}
